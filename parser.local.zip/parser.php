<!DOCTYPE HTML>
<html>
 <head>
  <meta charset="utf-8">
  <title>Parser Settings</title>
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
 </head>
 <body>

<?php

$from = $_POST["from"];
$where = $_POST["where"];
$data1 = $_POST["data1"];
$days = $_POST["days"];
$data2 = $_POST["data2"];






?>
</body>
	</html>